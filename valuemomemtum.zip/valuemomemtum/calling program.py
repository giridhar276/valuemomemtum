

import functions



functions.add()
print(functions.add.__doc__)

functions.copyfile('source','destination')
print(functions.copyfile.__doc__)

functions.readfile()
print(functions.readfile.__doc__)

functions.deletefile("abc.py")
print(functions.deletefile.__doc__)
