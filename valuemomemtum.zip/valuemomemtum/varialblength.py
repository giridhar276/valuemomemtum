# variable length args

# variable starting with * is the
#     TUPLE
def display(*info):
    for val in info:
        print(val)

display(10,20,30,'unix')




# variable starting with ** is the
#      dictionary

def displayvalues(**values):
    print(values)

displayvalues(chap1 = 10 ,chap2=20)


