# opening the file in write mode
fobj = open("clients.txt","w")

fobj.write("python programming\n")
fobj.write("scala language\n")
fobj.close()



##########################
## using context manager
#########################


with open("C:\\Users\\Admin\\Desktop\\demo.txt","w") as fobj:
    fobj.write("unix shell\n")
    


