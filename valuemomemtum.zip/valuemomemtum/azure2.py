import subprocess,shlex
import json

command = 'az dls fs list --account myazure --path / 2> out.txt'

command = shlex.split(command)

p = subprocess.Popen(command, shell = True , stdout=subprocess.PIPE, stderr=subprocess.PIPE)

out,err = p.communicate()
print(out.decode('utf-8'))

output = out.decode('utf-8')

data  = json.loads(output)

info = data[0]
for item in data[0]:
    print(item.ljust(30) , '    ' , info[item])

