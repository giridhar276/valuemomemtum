

# default args
def display(first=0,second=0,third='default'):
    print(first,second,third)

display()
display(10)
display(10,20)
display(10,20,30)

