
alist = []
alist = list()

atup = ()
atup = tuple()

# empty set
aset = set()
print(aset)

aset = {10,20,30}
bset = {30,40,50}

aset.add(40)
bset.add(60)

print(aset.union(bset))

print(aset.intersection(bset))

print(aset.issubset(bset))
print(aset.issuperset(bset))




