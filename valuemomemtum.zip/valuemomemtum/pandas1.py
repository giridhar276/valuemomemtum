

import pandas as pd
df = pd.read_csv('http://samplecsvs.s3.amazonaws.com/Sacramentorealestatetransactions.csv')


for record in df:
    print(record)
