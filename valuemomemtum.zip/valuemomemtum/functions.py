


def add():
    '''this is the help of add()'''
    print("this is add()")



def copyfile(source,destination):
    '''this is the help of copyfile '''
    print("this is copfile()")


def readfile():
    '''this is the help of readfile'''
    print("this is readfile()")


def deletefile(filename):
    
    '''this is the help of delete'''
    print("this is deletefile()")
    print("this is the file :", filename)


if __name__ == "__main__":
    add()
    copyfile('source','destination')
    readfile()
    deletefile("abc.py")
