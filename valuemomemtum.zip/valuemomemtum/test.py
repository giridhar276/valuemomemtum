






print(__name__)
