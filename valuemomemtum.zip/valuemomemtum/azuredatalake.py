from azure.datalake.store import core, lib


TENANT = 'cb3a6fcc-442d-4b73-b425-da084d441e91'
SECRET = 'U84hF??B=MT.2q5Ch9U-2UF:sF@=t9=x'
ID = '0941c179-3d42-41af-847e-a5358982d99f'

# Define the parameters needed to authenticate using client secret
token = lib.auth(tenant_id = TENANT,
                 client_secret = SECRET,
                 client_id = ID)


adl = core.AzureDLFileSystem(token, store_name='myazure')

print(adl)