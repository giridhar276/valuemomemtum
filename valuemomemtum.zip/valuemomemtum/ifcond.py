# simple if

name = "python"
if name == "python":
    print("String exists")


# if -elif... else
name = "python"

if name.isupper():
    print("String is upper")
elif name.islower():
    print("String is lower")


# if -elif-elif- else
filename = input("ENter any filename")
if filename.endswith(".py"):
    print("Python file")
elif filename.endswith(".sh"):
    print("bash file")
elif filename.endswith(".java"):
    print("java file")
else:
    print("Unknown file")

    


