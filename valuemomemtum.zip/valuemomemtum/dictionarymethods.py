adict = {"chap1":10 , "chap2":20 , "chap3":30}
print(adict)
print(adict["chap1"])  # 10
print(adict["chap2"])  # 20

## add new key-value to the dictionary
adict["chap4"] = 40
adict["chap5"] = 50

print(adict)

# display ONLY keys
print(adict.keys())
# display ONLY values
print(adict.values())
# dipslay key-value pairs
print(adict.items())

#print(adict["chap6"])
print(adict.get("chap6"))
print(adict.get("chap6",60))

bdict = {"chap7":70 , "chap8":80}

adict.update(bdict)
print(adict)

adict.pop("chap1")   # chap1-10 will be removed
print("Afrer removing :", adict)
adict.pop("chap2")   #  chap2-20 will be removed
print("Afrer removing :", adict)
adict.popitem()     # will remove random key-value pair
print("After popitem ", adict)

adict.setdefault("chap9",90)
print("After updating ", adict)




