try:
    with open("languages111.txt","r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)       
except Exception as error:
    print("Unknown error")
################### using cs library########
import csv
fobj = open("realestate.csv","r")
reader = csv.reader(fobj)

for line in reader:
    print(line)
         
########### file in the list format########## 
fobj = open("realestate.csv","r")
print(fobj.readlines())  # whole file in list
fobj.close()
############################################