
class Employee:
    def getName(self,name='default'):
        self.name = name
    def displayName(self):
        print("Employee name is :", self.name)
        


if __name__ == "__main__":
    # object is the instance of the class    
    emp1 = Employee()
    emp1.getName('Ram')
    emp1.displayName()       
            
    
    emp2 = Employee()
    emp2.getName('Ravi')
    emp2.displayName() 