name = "python programming"
print(name)
print(name.capitalize())
print(name.upper())
print(name.center(40))
print(name.center(40,"*"))
print(name.count("p"))
print(name.count("prog"))
print(name.endswith("z"))
print(name.startswith("p"))
print(name.isalnum())
aname = "I am working in {} and {}"
print(aname.format("java","python"))
print(aname.format(1,2))
output = name.split(" ")
print(output)
name = "   python programming "
print(name.strip())
print(name.lstrip())
print(name.rstrip())

name = "python"
print(name.rjust(20))

name = "python programming"
print(name.replace("python","scala"))
print(name)



print(len(name))

alist =[10,20,30]
print(len(alist))
adict = {"chap1":10 , "chap2":20}
print(len(adict))



























