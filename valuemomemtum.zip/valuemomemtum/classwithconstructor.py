
# constructor in python is defined in
#    __init__()
class Employee:
    def __init__(self,name='default'):
        self.name = name
    def displayName(self):
        print("Employee name is :", self.name)
        

# object is the instance of the class    
emp1 = Employee('Ram')
emp1.displayName()       
        

emp2 = Employee('Ravi')
emp2.displayName() 
