# list methods
# append :  passing single object
alist = [10,20,30]
alist.append(40)
print("After appending :", alist)
alist.append(50)
alist.append(700)
print("After appending :", alist)
# extennd : passing multiple values
alist.extend([1,900,40,987,10])
print("After extending :", alist)
getcount = alist.count(10)
print("Count of value is  :", getcount)
# insert( where to insert , what to insert )
alist.insert(0,5)
alist.insert(3,25)
print("After inserting :", alist)
# be default .. last index element will be removed
alist.pop()  ## will remove last element by default
print("After pop ", alist)
alist.pop(0)
print("After pop ", alist)
# value 10 will be removed
alist.remove(10)
print("After removing :",alist)


alist.sort()
print("After sorting :" , alist)

alist.reverse()
print("AFter reversing ", alist)


