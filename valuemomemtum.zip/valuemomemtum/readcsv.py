
import csv
fobj = open("realestate.csv","r")
reader = csv.reader(fobj)

for line in reader:
    print(line)