# string  slicing
#  string[start:stop:step]
name = "python programming"
print(name)
print(name[0])

print(name[1])

print(name[0:4])

print(name[4:10])
print(name[:10])
print(name[::])
print(name[:])
print(name[0:16:2])
print(name[0::2])
print(name[0:15:3])
print(name[::4])
print(name[-1])
print(name[-4:-1])
print(name[::-1])
