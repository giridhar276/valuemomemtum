import requests
import json
r = requests.get('https://api.github.com', auth=('giridhar276','0b26e55647cbc88aaff6a8c96e579a73ddc754a8'))
print(r.status_code)


info = json.loads(r.text)
for key in info:
    print(key.ljust(20) , ":"  , info[key])
