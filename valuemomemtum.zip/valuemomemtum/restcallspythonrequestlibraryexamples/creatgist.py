   
import requests
import json

server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)

local_file = "addtest.py"
with open(local_file) as fh:
    mydata = fh.read()
files = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : user,
    "files": {
    local_file : {
    "content": mydata
        }
      }
}
r1 = requests.post(url, data=json.dumps(files), auth=(user,'0b26e55647cbc88aaff6a8c96e579a73ddc754a8'))
print(r1.json())
