## display the current user repositories in github

from github import Github

# First create a Github instance:

# using username and password
#g = Github("giridhar276@gmail.com", "Nolimits1@")

#print(g)

g = Github("0b26e55647cbc88aaff6a8c96e579a73ddc754a8 ")

## all the repos
#for repo in g.get_repos():
#    print(repo)


for repo in g.get_user().get_repos():
    print(repo.name)
