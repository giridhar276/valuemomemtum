 
  
import requests

import json

server = "https://api.github.com"
endpoint = server + "/gists"
#endpoint = "https://api.github.com/users/giridharpython/gists"

r = requests.get(endpoint, auth=('giridharpython','0b26e55647cbc88aaff6a8c96e579a73ddc754a8'))

info = json.loads(r.text)


for item in info:
    for key in item:
        print(key.ljust(10), item[key])

    print("------------------------------------")