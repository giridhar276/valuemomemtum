 
    
import requests
import json
 


r = requests.get('https://api.github.com/users/giridharpython/gists', \
                 auth=('giridharpython','0b26e55647cbc88aaff6a8c96e579a73ddc754a8'))
 

info = json.loads(r.text)

#print(r.text)

for item in info:
    for key in item:
        print(key.ljust(10), item[key])

    print("------------------------------------")


