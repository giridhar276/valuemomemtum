import getopt, sys, os, errno  
import getpass    
import requests
import json
from requests.auth import HTTPBasicAuth
from requests.auth import HTTPDigestAuth
server = "https://api.github.com"
url = server + "/users"
user = "giridhar276"
#passwd = getpass.getpass('Password:')
print("checking ", url, "using user:", user)
r = requests.get(url, auth=HTTPBasicAuth(user,'2934dfe9ab555681eef4b7e41e2fac313607eb75'))
print(r)
