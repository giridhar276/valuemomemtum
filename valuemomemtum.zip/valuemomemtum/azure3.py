import subprocess,shlex
import json

command = 'az dls fs list --account myazure --path / 2> out.txt'

output = subprocess.getoutput(command)

output = json.loads(output)

print(output)

element = output[0]
for item in output[0]:
    print(element[item])
        
