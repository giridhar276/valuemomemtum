import subprocess,shlex
import json

command = 'az dls fs list --account myazure --path  /'

command = shlex.split(command)

p = subprocess.Popen(command, shell = True , stdout=subprocess.PIPE, stderr=subprocess.PIPE)

out,err = p.communicate()


print(out.decode('utf-8'))