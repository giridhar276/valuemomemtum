from  threading import Thread
import os  

def displayfile(file): 
    with open(file) as fobj:
        for line in fobj.readlines():
            print(line)

def run_threads():
    global threads
    for t in threads:
        t.start()
    for t in threads:
        t.join()
  

if __name__ == "__main__": 
    threads = []
    # creating thread 
    
    for file in os.listdir():
        if file.endswith(".py"):
            t1 = Thread(target=displayfile, args=(file,)) 
      
            # starting  thread 1 
            threads.append(t1)
            run_threads()
            threads = []
            